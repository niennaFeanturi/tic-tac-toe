export PHONE_NUMBER='+15554443322'
export AWS_REGION=us-west-2
export USER_POOL_ID=us-west-2_8oIAeBWcA
export COGNITO_CLIENT_ID=50jqbnk5ttdg39aj1iqo1ll0eo
export FUNCTION_ARN=arn:aws:lambda:us-west-2:622852669240:function:tictactoe-api
export BASE_URL=https://kw3el30m9j.execute-api.us-west-2.amazonaws.com/prod

